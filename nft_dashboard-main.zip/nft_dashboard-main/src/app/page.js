"use client";

import Homepage from "./components/Homepage";

export default function Home() {
	return (
		<main className=" w-full">
			<Homepage/>
		</main>
	);
}
