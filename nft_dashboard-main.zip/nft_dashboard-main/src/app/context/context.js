import { createContext } from "react";

export const sidebarWidth = createContext({});